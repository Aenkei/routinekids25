// Legacy file - not used in new architecture
// Keeping for compatibility but not active
import 'package:flutter/material.dart';

class UserRowWidget extends StatelessWidget {
  const UserRowWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const SizedBox.shrink();
  }
}